import classNames from "classnames";
import React, { useState, useRef } from "react";

export default function Input() {
  const elementRef = useRef();
  console.log(elementRef);
  return (
    <div>
      <button ref={elementRef}>Button</button>
    </div>
  );
}
