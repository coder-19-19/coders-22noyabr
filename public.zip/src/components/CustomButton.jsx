const CustomButton = ({ setName }) => {
  const changeName = () => {
    setName((prevState) => (prevState === "Farman" ? "Ali" : "Farman"));
  };

  return <button onClick={changeName}>Change Name</button>;
};

export default CustomButton;
