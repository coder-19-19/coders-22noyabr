import { useState } from "react";
import CustomButton from "./components/CustomButton";
import Input from "./components/input";

function App() {
  const [name, setName] = useState("Farman");

  const spanStyle = {
    color: name === "Farman" ? "green" : "blue",
  };

  const blogContent = "<p><h1>The most 10 bla bla</h1><img/></p>";

  return (
    <div>
      <span style={spanStyle}>{name}</span>
      <CustomButton setName={setName} />
      <span dangerouslySetInnerHTML={{ __html: blogContent }} />
      <Input/>
    </div>
  );
}

export default App;
