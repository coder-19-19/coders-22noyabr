import {Button, Card, CardBody, CardHeader, CardTitle, Col, FormText, Input, Label, Row} from "reactstrap";
import classNames from "classnames";
import {Controller, useForm} from "react-hook-form";
import {useEffect} from "react";
import users from './data.json'

function App() {
    console.log(users)
    const VALIDATION_MESSAGES = {
        required: 'Field is required',
        minLength: 'Filed must be 3 minimum'
    }
    const {handleSubmit, control, watch, setValue, formState:{errors}} = useForm({
        defaultValues: {
            name: 'Farman',
            surname:'Allahverdiyev'
        }
    })

    const onSubmit = (values) => {
        console.log(values)
    }

    const NameInput = ({field:{value,onChange}}) => (
        <div>
            <Label htmlFor="name">Name</Label>
            <Input name="name" value={value} onChange={onChange} className={classNames({
                'is-invalid': errors?.name
            })}/>
            <FormText color="danger">
                {errors?.name?.message}
            </FormText>
        </div>
    )

    const SurnameInput = ({field:{value, onChange}}) => {
        return <div>
            <Label htmlFor="surname">Surname</Label>
            <Input name="surname" onChange={onChange} value={value} className={classNames({
                'is-invalid': errors?.surname
            })}/>
           <FormText color="danger">
                {errors?.surname?.message}
            </FormText>
        </div>
    }

    const name = watch('name')

    useEffect(() => {
        const user = users.find(item => item.name === name)
        if(user) {
            setValue('surname', user.surname)
        }
    },[name])

  return (
      <div className="container">
          <Row className="justify-content-center mt-5">
              <Col sm={12} md={4}>
                  <Card>
                      <CardHeader>
                          <CardTitle className="fw-bold">Form</CardTitle>
                      </CardHeader>
                      <CardBody>
                          <form onSubmit={handleSubmit(onSubmit)}>
                              <Controller rules={{
                                  required: {
                                      value:true,
                                      message:VALIDATION_MESSAGES.required
                                  },
                                  minLength: {
                                      value: 3,
                                      message: VALIDATION_MESSAGES.minLength
                                  }
                              }} render={NameInput} name="name" control={control}/>
                              <Controller rules={{
                                  required: {
                                      value:true,
                                      message: VALIDATION_MESSAGES.required
                                  }
                              }} render={SurnameInput} name="surname" control={control}/>
                              <Button color="success w-100 mt-2">Submit</Button>
                          </form>
                      </CardBody>
                  </Card>
              </Col>
          </Row>
      </div>
  );
}

export default App;
