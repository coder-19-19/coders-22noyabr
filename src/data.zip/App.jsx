import {Button, Card, CardBody, CardHeader, CardTitle, Col, FormText, Input, Label, Row} from "reactstrap";
import classNames from "classnames";
import {Controller, useForm} from "react-hook-form";
import {useEffect, useState} from "react";
import users from './data.json'

function App() {
    const VALIDATION_MESSAGES = {
        required: 'Field is required',
        minLength:(length = 3) =>  `Filed must be ${length} minimum`
    }
    const {handleSubmit, control, watch, setValue, formState:{errors}} = useForm({
        defaultValues: {
            name: 'Farman',
            surname:'Allahverdiyev',
            gender: 1
        }
    })

    const PASSWORD_CHARS = '^(?=.*[!@#$%^&*:;=+|~`}{)(></"_\\[\\],\'.?-])'

    const [isPassword,setIsPassword] = useState(true)

    const onSubmit = (values) => {
        console.log(values)
    }

    const NameInput = ({field:{value,onChange}}) => (
        <div>
            <Label htmlFor="name">Name</Label>
            <Input name="name" value={value} onChange={onChange} className={classNames({
                'is-invalid': errors?.name
            })}/>
            <FormText color="danger">
                {errors?.name?.message}
            </FormText>
        </div>
    )

    const SurnameInput = ({field:{value, onChange}}) => {
        return <div>
            <Label htmlFor="surname">Surname</Label>
            <Input name="surname" onChange={onChange} value={value} className={classNames({
                'is-invalid': errors?.surname
            })}/>
           <FormText color="danger">
                {errors?.surname?.message}
            </FormText>
        </div>
    }

    const Note = ({field:{value, onChange}}) => {
        return <div>
            <Label htmlFor="note">Note</Label>
            <Input name="note" type="textarea" onChange={onChange} value={value}/>
        </div>
    }

    const PasswordInput = ({field:{value, onChange}}) => {
        return <div className="mt-2">
            <Button type="button" onClick={() => {
                setIsPassword(!isPassword)
            }
            }>Toggle type</Button>
            <Label htmlFor="password">Password</Label>
            <Input name="password" type={isPassword ? 'password' : 'text'} onChange={onChange} value={value} className={classNames({
                'is-invalid': errors?.password
            })}/>
            <FormText color="danger">
                {errors?.password?.message}
            </FormText>
        </div>
    }

    const name = watch('name')
    const surname = watch('surname')
    const gender = watch('gender')

    useEffect(() => {
        const user = users.find(item => item.name === name)
        if(user) {
            setValue('surname', user.surname)
        }
    },[name])

    useEffect(() => {
        if(Number(gender) === 2) {
            setValue('hm','')
        }
    },[gender])

  return (
      <div className="container">
          <Row className="justify-content-center mt-5">
              <Col sm={12} md={4}>
                  <Card>
                      <CardHeader>
                          <CardTitle className="fw-bold">Form</CardTitle>
                      </CardHeader>
                      <CardBody>
                          <form onSubmit={handleSubmit(onSubmit)}>
                              <Controller render={({field}) => (
                                  <label className="avatar">
                                      <Input type="file" onChange={e => {
                                          field.onChange(e.target.files[0])
                                      }}/>
                                      <div className="file">
                                          {field.value ? <img src={URL.createObjectURL(field.value)} alt="Profile Image"/> : `${name?.[0] || ''}${surname?.[0] || ''}`}
                                      </div>
                                  </label>
                              )} name="file" control={control}/>
                              <Controller rules={{
                                  required: {
                                      value:true,
                                      message:VALIDATION_MESSAGES.required
                                  },
                                  minLength: {
                                      value: 3,
                                      message: VALIDATION_MESSAGES.minLength()
                                  }
                              }} render={NameInput} name="name" control={control}/>
                              <Controller rules={{
                                  required: {
                                      value: true,
                                      message: VALIDATION_MESSAGES.required
                                  }
                              }} render={SurnameInput} name="surname" control={control}/>
                              <Controller render={Note} name="note" control={control}/>
                              <Controller render={({field:{value,onChange}}) => (
                                  <div>
                                      <div>
                                          <Label htmlFor="male">Male</Label>
                                          <Input onChange={onChange} checked={Number(value) === 1} type="radio" id="male" name="gender" value={1}/>
                                      </div>
                                        <div>
                                            <Label htmlFor="female">Female</Label>
                                            <Input onChange={onChange} checked={Number(value) === 2} type="radio" id="female" name="gender" value={2}/>
                                        </div>
                                  </div>
                              )} name="gender" control={control}/>
                              <Controller render={({field:{value,onChange}}) => (
                                  <div>
                                      <Label htmlFor="hm">Herbi Xidmet</Label>
                                      <Input name="hm" onChange={onChange} value={value} disabled={Number(gender) === 2}/>
                                  </div>
                              )} name="hm" control={control}/>
                              <Controller rules={{
                                required: {
                                    value:true,
                                    message:VALIDATION_MESSAGES.required
                                },
                                  minLength:{
                                    value:7,
                                      message:VALIDATION_MESSAGES.minLength(7)
                                  },
                                  pattern: {
                                      value: PASSWORD_CHARS,
                                      message: 'Must be include special char'
                                  }
                              }} render={PasswordInput} name="password" control={control}/>
                              <Button color="success w-100 mt-2">Submit</Button>
                          </form>
                      </CardBody>
                  </Card>
              </Col>
          </Row>
      </div>
  );
}

export default App;
